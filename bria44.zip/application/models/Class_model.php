<?php

class Class_model extends CI_Model{

    public function salvarProduto($obj){
       $this->db->insert('Produto', $obj);  
       return "Inserido com sucesso!";

    }
    public function salvarUser($obj){
        $nome = $obj['nome'];
        $query = $this->db->query("SELECT * FROM usuario WHERE nome='".$nome."'");
        if ($query->result() != NULL){
            return NULL;
        }      
        else {
            $this->db->insert('usuario', $obj);   
            return "Inserido com sucesso!";            
        }

    }
    public function verificarUser($nome,$senha,$tipo_usuario){     
        $query = $this->db->get_where('usuario', array('nome'=>$nome, 'senha'=>$senha,'tipo_usuario'=>$tipo_usuario));
        return $query->row_array();
    }
    public function listarProdutos(){
        $query = $this->db->get('Produto');
        return $query;
    }
    public function listarClientes(){
        $query = $this->db->get('usuario');
        return $query->result();
    }
    public function excluirCliente($cod){
        $table = array('usuario');
        $this->db->where('codigo',$cod);
        $this->db->delete($table);
    }
    public function excluirProduto($cod){
        $table = array('Produto');
        $this->db->where('codigo',$cod);
        $this->db->delete($table);
    }
    public function excluirHistorico($cod){
        $table = array('historico');
        $this->db->where('id',$cod);
        $this->db->delete($table);
    }
    public function update($obj){        
        $this->db->where('codigo',$obj['codigo']);
        $this->db->update('Produto', $obj);
    }
    public function upHistorico($obj){        
        $this->db->where('id',$obj['id']);
        $this->db->update('historico', $obj);
    }
    public function pendente(){        
        $query = $this->db->query("SELECT * FROM pedido p INNER JOIN historico h on p.id_historico = h.id INNER JOIN usuario u on u.codigo = p.id_usuario WHERE h.pagamento ='pendente' LIMIT 1");
    
        return $query->result();
    }	
    public function get_pedido($cod){
        $query = $this->db->query("SELECT * FROM pedido p INNER JOIN historico h on p.id_historico = h.id INNER JOIN usuario u on u.codigo = p.id_usuario WHERE h.pagamento = 'pendente' AND p.id_usuario = '".$cod."' LIMIT 1  ");
        return $query->result();        
        
    }   
    public function get_ped($id,$cod){
        $query = $this->db->query("SELECT * FROM pedido p INNER JOIN historico h on p.id_historico = h.id INNER JOIN usuario u on u.codigo = p.id_usuario WHERE h.id ='".$id."' AND p.id_usuario = '".$cod."' ");
        return $query->result();        
        
    }   
    public function get_pedidoProd($cod){
        $query = $this->db->query("SELECT p.id_historico,p.id_produto,pt.foto, pt.nome,pt.preco FROM pedido p INNER JOIN historico h on p.id_historico = h.id INNER JOIN Produto pt on pt.codigo = p.id_produto WHERE h.pagamento = 'pendente' AND p.id_usuario = '".$cod."'");
        return $query->result();        
        
    } 
    public function inserirHistorico($obj){        
        $this->db->insert('historico', $obj);
        $id = $this->db->insert_id();
        return  $id;
    }

    public function inserirPedido($cod_hist,$cod_usuario,$cod_produto){        
        $this->db->query("INSERT INTO pedido(id_historico,id_usuario,id_produto) VALUES ('".$cod_hist."','".$cod_usuario."','".$cod_produto."')");
    }
    public function insertUser($obj){ 
        $this->db->insert('usuario', $obj);        
    }
    public function getHistorico($cod){
        $query = $this->db->query("SELECT * FROM historico  WHERE id='".$cod."' ");
        return $query->result();        
        
    }    
    public function select($obj){
        $tipo_operacao = $obj['tipo_operacao'];
        $query = $this->db->query("SELECT * FROM Produto WHERE tipo_operacao='".$tipo_operacao."'");
        return $query->result();        
        
    }  
    public function getProduto($cod){
        $query = $this->db->query("SELECT * FROM Produto WHERE codigo='".$cod."'");
        return $query->result();        
        
    }    
    public function getUser($nome){
        $query = $this->db->query("SELECT * FROM usuario WHERE nome='".$nome."'");
        return $query->result();        
        
    }    
    public function get_usuario($cod){
        $query = $this->db->query("SELECT * FROM usuario WHERE codigo='".$cod."'");
        return $query->result();        
        
    } 
    public function logout(){
        $query = $this->db->query("SELECT * FROM usuario WHERE nome='".$nome."'");
        return $query->result();        
        session_destroy();
        
        
    }  
}

?>
