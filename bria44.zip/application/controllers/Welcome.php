<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('email');	
		$this->load->library('session');				
		$this->load->library('cart');	
		$this->load->model('Class_model','model');

	}
	public function index()
	{
	/*	$this->load->library('session');
		
		//restrict users to go back to login if session has been set
		if($this->session->userdata('user')){
			header('home');
		}
		else{
			$this->load->view('login_page');
		}
		*/	
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
				$nome = $_POST['nome'];
				$senha = md5($_POST['senha']);
				$tipo_usuario = $_POST['tipo_usuario'];
				$data = $this->model->verificarUser($nome, $senha,$tipo_usuario);
				if($data){
					$_SESSION['nome'] = $nome;					
					$_SESSION['tipo_usuario'] = $tipo_usuario;
					$this->session->set_userdata('usuario', $data);
					header('Location:listarProduto');											
					
				}
				else{
					$this->session->set_flashdata('error','Usuario ou Senha incorretos');
					$this->load->view('login');	
					
				} 
		}
		else{
			$this->load->view('login');	
		}
	
	}
	public function addCarrinho(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){			
			$cod = $_POST['codigo'];
			$obj=$this->model->getProduto($cod);
			foreach ($obj as $item) {			
				$dado = array(
					'id' => $item->codigo,				
					'name' => $item->foto,
					'qty'  => $_POST['quant'],				
					'price'  => $item->preco,
					'options'  =>  array ( 'peso'  =>  $item->peso_produto, 'quantidade'=>$item->quantidade) 				
				);		
			}
			$this->cart->insert($dado);
			$this->load->view('produtos');
		}		
		else{
			$this->load->view('produtos');			
		}
	}
	public function pagar(){
		$soma = 0;	
		$peso_soma = 0;			
		foreach ($this->cart->contents() as $item) {
				$peso_soma+=intval($this->cart->format_number($item['options']['peso'])* intval($item['options']['quantidade']));
		     	$soma += intval($item['price'])* intval($item['qty']);
						
		}	

		$obj=$this->model->getUser($_SESSION['nome']);
		foreach ($obj as $item) {
			$estado = $item->estado;
		}
		$vetor1 = ['RS', 'SC', 'PR'];
		$vetor2 = ['SP', 'RJ', 'ES','MG', 'MT', 'MS'];
		$vetor3 = ['RO', 'BA', 'GO','TO', 'SE','AL'];
		$pos1 = array_search( $estado,$vetor1);
		$pos2 = array_search( $estado,$vetor2);
		$pos3 = array_search( $estado,$vetor3);	
		$aux = 2;
		$frete = 0;
		if ($pos1 === 0){
			$pos1 = 1;
		}
		if ($pos2 === 0){
			$pos2 = 1;
		}
		if ($pos3 === 0){
			$pos3 = 1;
		}
		if($pos1!=NULL ){
			if($peso_soma < 1){
				$soma +=15;
				$frete =15;
			}
			if($peso_soma >=1 && $peso_soma <2  ){
				$soma +=25;
				$frete=25;
			}
			if($peso_soma >=2 && $peso_soma <5  ){
				$soma +=55;
				$frete = 55;
			}
			if($peso_soma >=5){
				$soma +=95;
				$frete = 95;
				
			}
			$aux = 1;			
		}
		if($pos2!=NULL ){
			if($peso_soma < 1){
				$soma +=30;
				$frete = 30;				
			}
			if($peso_soma >=1 && $peso_soma <2  ){
				$soma +=50;
				$frete = 50;				
				
			}
			if($peso_soma >=2 && $peso_soma <5  ){
				$soma +=110;
				$frete = 110;				
				
			}
			if($peso_soma >=5){
				$soma +=190;
				$frete = 190;								
				
			}
			$aux = 1;			
			
		}
		if($pos3!=NULL){
			if($peso_soma < 1){
				$soma +=45;
				$frete = 45;				
				
			}
			if($peso_soma >=1 && $peso_soma <2  ){
				$soma +=65;
				$frete = 65;				
				
			}
			if($peso_soma >=2 && $peso_soma <5  ){
				$soma +=140;
				$frete = 140;								
			}
			if($peso_soma >=5){
				$soma +=210;
				$frete = 210;								
			}
			$aux = 1;			
			
		}
		if($aux === 2){
			if($peso_soma < 1){
				$soma +=50;
				$frete = 50;								
			}
			if($peso_soma >=1 && $peso_soma <2  ){
				$soma +=80;
				$frete = 80;				
				
			}
			if($peso_soma >=2 && $peso_soma <5  ){
				$soma +=170;
				$frete = 170;				
				
			}
			if($peso_soma >=5){
				$soma +=240;
				$frete = 240;				
				
			}
			
		}
		$dado=["soma"=>$this->cart->format_number($soma),"frete"=>$this->cart->format_number($frete)];
		$this->load->view('pagar',$dado);	
	}
	public function inserirProduto(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$foto = $_FILES['foto']['name'];
			$ext = pathinfo($foto, PATHINFO_EXTENSION);
			$nome_foto = md5(uniqid(time())).".".$ext;	
			$dir =$_SERVER['DOCUMENT_ROOT'].'/briao/'.$nome_foto;	
			move_uploaded_file($_FILES['foto']['tmp_name'], $dir);						
			chmod($dir, 0777);		
			$obj = array(
				'descricao' => $_POST['descricao'],
				'foto'  => $nome_foto,
				'quantidade'  => $_POST['quantidade'],				
				'palavraChave'  => $_POST['palavraChave'],			
				'preco'  => $_POST['preco'],
				'peso_produto'  =>$_POST['peso_produto']
				
			);	
			$this->model->salvarProduto($obj);	
			header('listarProduto');		
		}
		else {
			$obj['produto'] = array(['teste']);
			$obj['texto'] = "Inserir Produto";			
			$this->load->view('inserirProduto',$obj);	
			
		}		
	}

	public function alterarProduto(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){		
			$foto = $_FILES['foto']['name'];
			$ext = pathinfo($foto, PATHINFO_EXTENSION);
			$nome_foto = md5(uniqid(time())).".".$ext;	
			$dir =$_SERVER['DOCUMENT_ROOT'].'/briao/'.$nome_foto;	
			move_uploaded_file($_FILES['foto']['tmp_name'], $dir);						
			chmod($dir, 0777);						
			$obj = array(
				'codigo' => $_POST['codigo'],				
				'descricao' => $_POST['descricao'],
				'foto'  => $nome_foto,
				'quantidade'  => $_POST['quantidade'],				
				'palavraChave'  => $_POST['palavraChave'],			
				'preco'  => $_POST['preco'],
				'peso_produto'  =>$_POST['peso_produto']
				
				
			);	
			
			$this->model->update($obj);
			header('listarProduto');			
			
		}
		else {
			$cod = $_GET['cod'];
			$obj['texto'] = 'Alterar Produto';			
			$obj['produto'] = $this->model->getProduto($cod);	
			$this->load->view('inserirProduto',$obj);
			
		}		    		
		
	}
	public function quantidade(){	
		$obj['produto'] = $this->model->getProduto($_GET['cod']);
		$this->load->view('quantidade',$obj);
		
		
	}
	public function confirmarCompra(){	
		$obj['clientes'] = $this->model->pendente();
		$this->load->view('confirmarCompras',$obj);
		
	}
	public function invalidar(){	
		$dado = $this->model->get_usuario($_GET['id_user']);		
		$obj['clientes'] = $this->model->excluirHistorico($_GET['id_hist']);
		foreach ($dado as $user) {
			$this->email->from('sp.lorranapereira@gmail.com', 'ADMIN');
			$this->email->to($user->email);
			$this->email->subject('conta inválida'); 			
			$this->email->message('Sua compra foi negada');
			$this->email->send();		
		}

		header('Location:listarClientes');			
		
	}
	public function visualizarCompra(){	
		$obj['clientes'] = $this->model->get_pedido($_GET['id_usuario']);
		$obj['produtos'] = $this->model->get_pedidoProd($_GET['id_usuario']);
		$this->load->view('visualizarCompras',$obj);
	
	//	print_r($obj['clientes']);
	}
	public function salvarCompra(){		
		$obj = $this->model->getUser($_SESSION['nome']);
		foreach ($obj as $item) {
			$cod_user = $item->codigo;
		}
		$obj = array(
			'banco' => $_POST['banco'],
			'agencia'  => $_POST['agencia'],
			'conta'  => $_POST['conta'],			
			'deposito'  => $_POST['deposito'],
			'pagamento'  => 'pendente'
			
			
		);	
		$id_hist = $this->model->inserirHistorico($obj);	
		foreach ($this->cart->contents() as $item) {
			$this->model->inserirPedido($id_hist,$cod_user,$item['id'],$item['qty']);
		}

		header('Location:listarProduto');					
		//$this->load->view('consultar');
		
	}
    public function confirmar()
	{

		$id_hist= $_GET['id_hist'];
		$id_user= $_GET['id_user'];
		$data = $this->model->getHistorico($id_hist);
		foreach ($data as $hist) {
			$array = array(
				'id' =>  $hist->id,				
				'banco' =>  $hist->banco,
				'agencia'  =>  $hist->agencia,
				'pagamento'  =>  'feito',	
				'deposito'  =>  $hist->deposito,				
				'conta'  =>  $hist->conta	
			);	
		}
		//$obj = $this->model->upHistorico($array);		
		$prod = $this->model->get_ped($id_hist,$id_user);
		
		foreach ($prod as $item) {
			$dado = $this->model->getProduto($item->id_produto);
			foreach ($dado as $produto) {
				$descontar = intval($produto->quantidade);
				$conta=  $descontar-intval($item->quant);
				$novo = array(
					'codigo' =>  $produto->codigo,				
					'descricao' =>  $produto->descricao,
					'foto'  =>  $produto->foto,
					'quantidade'  =>  $conta,				
					'palavraChave'  =>  $produto->palavraChave,			
					'preco'  =>  $produto->preco,
					'peso_produto'  => $produto->peso_produto	
				);
				
			
		    };
		}
	//	$obj = $this->model->update($novo);
		$dado = $this->model->get_usuario($id_user);	
		foreach ($dado as $user) {
			$this->email->from('sp.lorranapereira@gmail.com', 'ADMIN');
			$this->email->to($item->email);
			$this->email->subject('compra'); 			
			$this->email->message('Sua compra foi finalizada com sucesso e está sendo entregue pelo correio.');
			$this->email->send();		
		}
		header('Location:listarProduto');		
		
	}
	public function mensagem()
	{
		if ($_SERVER['REQUEST_METHOD'] == "POST"){				
			$this->email->from('sp.lorranapereira@gmail.com', 'ADMIN');
			$this->email->to('sp.lorranapereira@gmail.com');
			$this->email->subject($_POST['assunto']); 			
			$this->email->message($_POST['texto']);
			$this->email->send();
			header('Welcome/listarProduto');		
			
		}else {
			$this->load->view('mensagem');				
		}
	}
	public function listarCLientes(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){	
			$data['clientes'] = $this->model->listClientes();
			
		}		
		$data['clientes'] = $this->model->listarClientes();		
		$this->load->view('listarClientes',$data);	
		
	}	
	public function salvarConsulta(){
		$obj = array(
			'bairro' => $_POST['bairro'],
			'dormitorios'  =>$_POST['dormitorios'],
			'tipo_operacao'  => $_POST['tipo_operacao']
			
		);		
		$data['imoveis'] = $this->model->select($obj);
		$this->load->view('listar',$data);	
		
	}	
	public function listarProduto(){
		if(isset($_GET['log'])){
			$_SESSION['tipo_usuario'] = 'nao';
		}
		$data['produtos'] = $this->model->listarProdutos()->result();	
		$this->load->view('listarProdutos',$data);
	}
	public function excluirCliente(){
		$data['produtos'] = $this->model->excluirCliente($_GET['id_user']);	
		header('Location:listarClientes');			
		
	}
	public function deletarProduto(){
		$data['produtos'] = $this->model->excluirProduto($_GET['cod']);	
		header('Location:listarProduto');			
		
	}
	public function deletarProdutoCarr(){
		$deleteItem = array(
			'rowid' => $_GET['cod'],
			'qty'   => 0
		);
		$this->cart->update($deleteItem);	
		header('Location:addCarrinho');			
		
		
	}
	public function cadastro(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){	
			$novo = array (
				'nome' =>  $_POST['nome'],
				'email'  =>   $_POST['email'],
				'cidade'  =>  $_POST['cidade'],				
				'estado'  =>  $_POST['estado'],			
				'senha'  =>  md5($_POST['senha']),
				'endereco'  =>  $_POST['endereco'],				
				'tipo_usuario'  => $_POST['tipo']	
			);
			$_SESSION['nome'] = $novo['nome'];					
			$_SESSION['tipo_usuario'] = $novo['tipo_usuario'];
			$this->session->set_userdata('usuario', $novo);
			$this->model->insertUser($novo);
			header('Location:listarProduto');						
		}	
		else {
			$this->load->view('cadastro');	
		}	
		
	}
	public function pdfclientes(){	
		require_once("fpdf/fpdf.php");
		$pdf= new FPDF("L","pt","A4");	
		$pdf->AddPage();	
		$data['produtos'] = $this->model->listarClientes();			
		foreach ($data['produtos'] as $row){
			$pdf->SetFont('arial','B',12);
			$pdf->Cell(0,5,"Codigo: ".$row->codigo,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Email: ".$row->email,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Estado: ".$row->estado,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Cidade: ".$row->cidade,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Enreço: ".$row->endereco,0,1,'L');
			$pdf->Ln(20);
		}
		$pdf->Output();		
	}
	
	public function logout(){
		session_destroy();
		$this->cart->destroy();
		header('Location:index');
	}
}
