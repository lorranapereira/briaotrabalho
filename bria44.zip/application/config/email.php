<?php
    $config['smtp_host'] = 'ssl://smtp.gmail.com';
    $config['smtp_port'] = 465;
    $config['smtp_user'] = 'ds1testec1@gmail.com';
    $config['smtp_pass'] = 'ds12321sd';
    $config['protocol']  = 'smtp';
    $config['validate']  = TRUE;
    $config['mailtype']  = 'html';
    $config['charset']   = 'utf-8';
    $config['newline']   = "\r\n";
?>
