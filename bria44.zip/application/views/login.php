<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
<div id="container">

    <div class="container">   
    <?php
		if ($this->session->flashdata('error')) {
		?>
            <div class="alert alert-danger text-center" style="margin-top:20px;">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
            <?php
		}
	?> 
        <div id="loginbox" style="margin-top:50px;" name="login" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <form id="loginform" action="/index.php/Welcome/index" method="POST" class="form-horizontal" role="form">   
               <label for="">Usuario</label>
               <input id="login-username" type="text" class="form-control" name="nome" value="" placeholder="username or email" required>                                        
               <label for="">Senha</label>
               <input id="login-password" type="password" class="form-control" name="senha" placeholder="password" required>
                 <select name="tipo_usuario" id="">
                     <option value="sim">Sim</option>
                     <option value="nao">Nao</option>
                 </select>
               <button type="submit">Enviar</button>
                
            </form>  
            <br/> 
            <a href="listarProduto?log=nao">Visualizar Produtos</a>  <br/>   
            <a href="cadastro">Cadastre-se</a>                                
                            
        </div>
    </div>

</body>
</html>
